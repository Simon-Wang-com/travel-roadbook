#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""一键交稿自检（v2.7 严格版，给「不太会写代码的模型」用的硬闸门）。

用法（只有这一条，别自己发明参数）:
    python scripts/verify_roadbook.py --html 路书.html

退出码：0 = 可以交付；1 = 不许交付（按输出里的「怎么修」改）。
"""
import argparse
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REQUIRED = ["v-home", "v-prep", "v-itinerary", "v-spots", "v-food", "v-budget"]

# 功能完整性：这些能力必须真的存在（只换内容，不许整块删掉/改名/关掉）
FEATURES = [
    ("景点实拍图数据 V543_IMGS", "V543_IMGS"),
    ("景点别名映射 V600_ALIAS", "V600_ALIAS"),
    ("打卡热度榜弹层 v46", "v46-ov"),
    ("返回/关闭条 v564", "v564-back"),
    ("导航内核 __navTo", "__navTo"),
    ("票据识别页 v-ocr", 'id="v-ocr"'),
    ("记账页 v-budget", 'id="v-budget"'),
    ("景点打卡页 v-spots", 'id="v-spots"'),
    ("行程页 v-itinerary", 'id="v-itinerary"'),
    ("天数自适应 v15", "v15-anyday-js"),
    ("防退化护栏 v601", "v601-guard-js"),
    ("详情页实拍横幅", "v600-detail-photo"),
    ("转场层 v512", "v512"),
    ("背景层 v594", "v594"),
    ("滚动修复层 v23", "v23-scrollfix-js"),
    ("顺路判定层 v24", "v24-foodroute"),
    ("附近美食入口", 'id="v46-near"'),
    ("首页版本徽标", 'id="rbVer"'),
    ("热度榜条目", "v46-rank"),
    ("美食三 tab", 'data-v46-open="local"'),
    ("日卡实拍兜底 v2.7", "v27-fix-js"),
    ("选中态/底纹 v2.7 CSS", "v27-fix-css"),
]


def load(path):
    try:
        return io.open(path, encoding="utf-8").read()
    except Exception as e:
        print("FAIL 读不到文件：%s（%s）" % (path, e))
        sys.exit(1)


def sections(html):
    ids = set(re.findall(r'<section[^>]*\bclass="[^"]*\bview\b[^"]*"[^>]*\bid="([^"]+)"', html))
    ids |= set(re.findall(r'<section[^>]*\bid="([^"]+)"[^>]*\bclass="[^"]*\bview\b', html))
    return ids


def visible_text(html):
    s = re.sub(r"<script\b[^>]*>.*?</script>", " ", html, flags=re.S | re.I)
    s = re.sub(r"<style\b[^>]*>.*?</style>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<!--.*?-->", " ", s, flags=re.S)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"&nbsp;|&amp;|&lt;|&gt;|&quot;", " ", s)
    return re.sub(r"\s+", " ", s)


def is_blank_template(html):
    # v2.6：只有「4 张以下占位日卡 + 四个空数组」才算空白模板；
    # 实测 WorkBuddy 把 S/F 清空却保留 8 张真日卡，旧判定会把它当模板放行全部结构检查。
    cards = len(re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"', html))
    return (("var F=[]" in html) and ("var S=[]" in html) and ("var SPOTS=[]" in html) and cards <= 4)


def check_structure(html, ids, blank):
    bad = []
    for r in REQUIRED:
        if r not in ids:
            bad.append("缺板块 %s" % r)
    if len(ids) < 30 and not blank:
        bad.append("板块只有 %d 个（模板基线 38，正常路书至少 30；少了就是被整块删了）" % len(ids))
    docks = set(re.findall(r'data-dock="([^"]+)"', html))
    if len(docks) < 5:
        bad.append("Dock 只剩 %d 项（至少 5 项：首页/准备/行程/美食/记账）" % len(docks))
    for t in sorted(docks):
        if t not in ids:
            bad.append("Dock 指向不存在的板块 %s" % t)
    if 'id="dayTabs"' not in html:
        bad.append("缺少天数 tab 容器 #dayTabs（天数自适应被拆了）")
    return bad


def check_nav_targets(html, ids):
    bad = []
    for attr in ("data-nav", "data-v46-go", "data-v15-go", "data-v564-go", "data-dock"):
        miss = []
        for m in re.finditer(attr + r'="([^"]+)"', html):
            t = m.group(1).strip()
            if not t or any(c in t for c in "+$"):
                continue
            if t.startswith("v-") and t not in ids:
                miss.append(t)
        if miss:
            uniq = sorted(set(miss))
            bad.append("%s 指向不存在的板块 %d 处：%s" % (attr, len(miss), "、".join(uniq[:8]) + ("…" if len(uniq) > 8 else "")))
    return bad



def check_day_selector(html):
    """v2.6：日卡统计只许 .daycard。
    实测 WorkBuddy 新版：querySelectorAll('.daycard, [data-day]') 把 body[data-day]
    和 8 个装饰层 .v514-art[data-day] 也当日卡，8 张真卡算成 16 张，生成 Day 1–16，
    双数 tab 对应装饰层所以点开空白。"""
    bad = []
    if "querySelectorAll('.daycard, [data-day]')" in html:
        bad.append("日卡统计用了并集选择器 querySelectorAll('.daycard, [data-day]')：body[data-day] / .v514-art[data-day] 会被算成日卡 → 8 张卡生成 16 个 tab、双数 tab 空白；只许 .daycard，老页面兜底用 .card[data-day]")
    if "querySelector('.daycard, [data-day]')" in html:
        bad.append("建 tab 插入点也用了并集选择器 .daycard, [data-day]；改成 .daycard，兜底 .card[data-day]")
    if "if(n>=cards.length)" in html:
        bad.append("tab 数量判定用了 n>=cards.length：旧 tab 多于日卡时也会误判为「够了」；改成 n===cards.length")
    return bad


def check_stray_text(html):
    """v2.6：</script> 后不许留裸 '>' 文本节点。
    实测 WorkBuddy 新版在 V5.68-78 追加层 </script> 后留了一个 '>'，
    浏览器把它渲染到屏幕左缘，就是用户红圈里的「尖尖箭头」。"""
    bad = []
    for m in re.finditer(r'</(?:script|style)>\s*>\s*', html):
        ctx = html[max(0, m.start() - 30):m.start() + 30].replace("\n", " ")
        bad.append("发现 </script>/<style> 后的游离 '>' 文本节点（会渲染成左缘尖箭头）：…%s…；删掉这个字符" % ctx)
    return bad


def check_spots(html):
    bad = []
    if re.search(r"cities\s*=\s*\[\s*['\"]杭州", html):
        bad.append("打卡热度榜分组还写死模板的杭州/南京 → SPOTS 里的新景点永远进不去")
    if re.search(r"共\s*0\s*个\s*点位", html):
        bad.append("打卡热度榜出现「共 0 个点位」→ 景点列表是空的")
    if not re.search(r'class="[^"]*\bv46-rank\b', html):
        bad.append("打卡热度榜没有任何 .v46-rank 条目 → 景点是空的")
    return bad


def check_details(html, ids, blank):
    bad = []
    if blank:
        return bad
    i = html.find("var S=")
    seg = html[i:i + 12000] if i >= 0 else ""
    ds = re.findall(r"d:'([^']+)'", seg)
    miss = sorted(set(d for d in ds if d.startswith("v-") and d not in ids))
    if miss:
        bad.append("S 数组里的详情页目标不存在 %d 个：%s" % (len(miss), "、".join(miss[:8]) + ("…" if len(miss) > 8 else "")))
    spots = sorted(x for x in ids if x.startswith("v-spot-"))
    if len(spots) < 3:
        bad.append("景点详情页只有 %d 个（本次行程至少要有 3 个 v-spot-*）" % len(spots))
    for sid in spots:
        m = re.search(r'<section[^>]*\bid="%s"[^>]*>(.*?)</section>' % re.escape(sid), html, flags=re.S)
        if not m:
            bad.append("详情页 %s 找不到完整 <section> 内容" % sid)
            continue
        body = m.group(1)
        text = re.sub(r"<[^>]+>", "", body)
        text = re.sub(r"\s+", " ", text).strip()
        if len(text) < 80:
            bad.append("详情页 %s 正文只有 %d 字 → 是空壳" % (sid, len(text)))
        if "data-img=" not in body and "v600-detail-photo" not in body:
            bad.append("详情页 %s 没有实拍图位（data-img / v600-detail-photo）" % sid)
        if "<div class=\"hero\"" not in body and "<div class='hero'" not in body and "class=\"hero\"" not in body:
            bad.append("详情页 %s 缺少 .hero 标题区" % sid)
    return bad


def check_photos(html, blank):
    bad = []
    if blank:
        return bad
    i = html.find("V543_IMGS")
    seg = html[i:i + 20000] if i >= 0 else ""
    n = seg.count("data:image/")
    if n < 1:
        bad.append("V543_IMGS 里一张内嵌实拍图都没有（景点图会被运行时联网兜底拖死）")
    return bad


def check_day_covers(html, blank):
    """v2.7：非空白页的景点图 key 不能少于日卡张数。
    实测 WorkBuddy 7 天页：Day1 广州 / Day3 稻城 有内嵌图却取不到，
    因为 SPOTS 精确别名缺城市级写法；这里先卡「图数 < 天数」的硬缺口，
    再由 v27-fix-js 在运行时按 SPOTS 名字前缀逐张校正。"""
    bad = []
    if blank:
        return bad
    cards = len(re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"', html))
    i = html.find("window.V543_IMGS=")
    seg = html[i:i + 6000000] if i >= 0 else ""
    keys = re.findall(r'"([^"]+)"\s*:\s*"data:image/', seg)
    if cards and len(keys) < cards:
        bad.append("景点图 key 只有 %d 个，少于 %d 张日卡：必然有几天「找图中/暂无实拍图」" % (len(keys), cards))
    return bad


def check_version(html):
    bad = []
    m = re.search(r'<section[^>]*id="v-home"[^>]*>(.*?)(?=<section[^>]*\bid="v-(?!home)|$)', html, flags=re.S)
    home = m.group(1) if m else ""
    v = re.search(r'id="rbVer"[^>]*>(.*?)<', home, flags=re.S)
    if not v:
        bad.append('首页没有版本号徽标 <span id="rbVer">v0.1</span>（v2.2 起强制标在首页）')
        return bad
    text = re.sub(r"<[^>]+>", "", v.group(1)).strip()
    if not re.match(r"v\d+\.\d+$", text):
        bad.append("首页版本号 %r 不是 v{十位}.{个位} 格式（第一版 v0.1、第十版 v1.0）" % text)
    tip = re.search(r"本页 (v\d+\.\d+)", html)
    if not tip:
        bad.append("找不到 #wechatTip 的「本页 vX.Y」版本号，三处必须同号")
    elif tip.group(1) != text:
        bad.append("首页版本号 %s 与 #wechatTip 的 %s 不一致，三处必须同号" % (text, tip.group(1)))
    return bad


def check_days(html):
    bad = []
    tags = re.findall(r'<div[^>]*class="[^"]*\bdaycard\b[^"]*"[^>]*>', html)
    cards = len(tags)
    if cards == 0:
        bad.append("行程页没有 .daycard（一天一张日卡）")
    days = []
    for t in tags:
        m = re.search(r'data-day="(\d+)"', t)
        if m:
            days.append(int(m.group(1)))
    if cards and len(days) != cards:
        bad.append("有 %d 张日卡但只有 %d 张写了 data-day，编号缺失" % (cards, len(days)))
    if days:
        uniq = sorted(set(days))
        if uniq != list(range(1, max(uniq) + 1)):
            bad.append("日卡 data-day 不连续：%s（必须 1..N 连续）" % uniq)
    if re.search(r"for\s*\(\s*d\s*=\s*0\s*;\s*d\s*<\s*4\s*;", html):
        bad.append("写死 4 天：for(d=0;d<4)")
    if "四天全部显示" in html:
        bad.append("写死文案：四天全部显示")
    i = html.find('id="v-itinerary"')
    seg = html[i:i + 6000] if i >= 0 else ""
    h1 = re.search(r'<h1[^>]*>(.*?)</h1>', seg, flags=re.S)
    if h1:
        title = re.sub(r"<[^>]+>", "", h1.group(1))
        hm = re.search(r'Day\s*1\s*[–-]\s*(\d+)', title)
        if hm and int(hm.group(1)) != cards:
            bad.append("行程页标题写死 Day 1–%s，但页面有 %d 张 .daycard（标题必须跟日卡数一致）" % (hm.group(1), cards))
    return bad, cards


def check_food(html, blank):
    bad = []
    if blank:
        return bad
    i = html.find("var F=")
    seg = html[i:i + 120000] if i >= 0 else ""
    keys = re.findall(r"\{k\s*:\s*['\"]([^'\"]+)", seg)
    n = len(keys)
    r0 = seg.count("route:0")
    r1 = seg.count("route:1")
    if n >= 4 and r0 == 0:
        bad.append("美食 %d 道全部标成顺路（route:0 为 0）：顺路/绕路没有区分" % n)
    if n >= 4 and r1 == 0:
        bad.append("美食 %d 道全是绕路（route:1 为 0）：默认页会空" % n)
    if n >= 3:
        for k in keys:
            chunk = re.search(r"\{k\s*:\s*['\"]%s['\"][\s\S]*?(?=\{k\s*:|$)" % re.escape(k), seg)
            if not chunk:
                continue
            c = chunk.group(0)
            for field in ("c:", "g:", "rests:"):
                if field not in c:
                    bad.append("美食 %s 缺字段 %s（每条必须有城市/天数/代表餐厅）" % (k, field[:-1]))
                    break
    if "v24-foodroute" not in html:
        bad.append("缺少顺路自动判定层 v24-foodroute（只靠手写 route 标记不算）")
    if 'id="v46-near"' not in html:
        bad.append("美食页缺少「附近美食」入口（按定位搜高德 3 公里内餐饮）")
    if re.search(r"groupHTML\(on,", html):
        bad.append("「本地美食」页重复渲染顺路款，两页看起来一样")
    return bad


def check_placeholders(html, blank):
    bad = []
    if blank:
        return bad
    text = visible_text(html)
    for t in ("TODO", "待补", "待填", "暂无内容", "占位", "示例城市", "共 0 个点位", "共0个点位"):
        if t in text:
            bad.append("正文还有占位/示例内容：%s" % t)
    return bad


def check_scripts(html):
    if not shutil.which("node"):
        print("SKIP 本机没有 node，跳过 JS 语法检查（不扣分，但建议装 Node.js 后复跑）")
        return []
    blocks = re.findall(r"<script\b[^>]*>(.*?)</script>", html, flags=re.S | re.I)
    bad = []
    for i, code in enumerate(blocks):
        if not code.strip():
            continue
        fd, tmp = tempfile.mkstemp(suffix=".js")
        os.close(fd)
        with io.open(tmp, "w", encoding="utf-8") as f:
            f.write(code)
        r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True)
        os.unlink(tmp)
        if r.returncode != 0:
            bad.append("第 %d 个 <script> 语法错：%s" % (i + 1, (r.stderr or "").strip().splitlines()[-1] if r.stderr else ""))
    return bad


def check_leftovers(path):
    script = os.path.join(HERE, "check_demo_leftovers.py")
    if not os.path.exists(script):
        print("SKIP 找不到 check_demo_leftovers.py")
        return []
    r = subprocess.run([sys.executable, script, "--html", path], capture_output=True, text=True)
    if r.returncode == 0:
        return []
    lines = (r.stdout or "").strip().splitlines()
    return ["模板示例残留检查未通过：" + (lines[0] if lines else "退出码 %d" % r.returncode)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True)
    ap.add_argument("--expect-days", type=int, default=0,
                    help="用户明确说的天数；填了就把日卡数卡死，不一致直接 FAIL")
    a = ap.parse_args()
    html = load(a.html)
    size = len(html.encode("utf-8"))
    if size < 1_500_000:
        print("FAIL 文件只有 %d KB，像是空壳/没写完整（正常路书 ≥ 1.5MB）" % (size // 1024))
        return 1

    blank = is_blank_template(html)
    ids = sections(html)
    fails = []
    fails += check_structure(html, ids, blank)
    fails += check_nav_targets(html, ids)
    fails += check_day_selector(html)
    fails += check_stray_text(html)
    fails += check_spots(html)
    fails += check_details(html, ids, blank)
    fails += check_photos(html, blank)
    fails += check_day_covers(html, blank)
    fails += check_version(html)
    for label, marker in FEATURES:
        if marker not in html:
            fails.append("功能缺失：%s（标记 %r 找不到，被整块删了？）" % (label, marker))
    day_bad, cards = check_days(html)
    fails += day_bad
    if a.expect_days and cards != a.expect_days:
        fails.append("用户明确要 %d 天，页面却有 %d 张 .daycard（多/少一天都算内容错误）" % (a.expect_days, cards))
    fails += check_food(html, blank)
    fails += check_placeholders(html, blank)
    fails += check_scripts(html)
    fails += check_leftovers(a.html)

    if fails:
        print("FAIL 不许交付（%d 项）：" % len(fails))
        for x in fails:
            print("  - " + x)
        print("\n怎么修（照着做，别猜）：")
        print("  1) 缺板块/功能 → 从 assets/template.html 把整块搬回来，只换内容，不许删")
        print("  2) 缺详情页 → 每个 S 里的 d 和行程入口都要有真实 <section id=\"v-spot-*\">，带 hero + data-img")
        print("  3) 天数 → 一天一张 .daycard，data-day 从 1 连续到 N；tab 交给 buildTabs，别写死")
        print("  4) 美食 → 每条写 c/g/rests，route:0 只进「本地美食 · 需绕路」，两页不重复")
        print("  4b) 日卡图 → 图 key 数必须 ≥ 日卡数；缺 v27-fix-js 就补回日卡实拍兜底层，不能靠“找图中”")
        print("  5) Day 1–16 / 双数空白 → 日卡统计只许 .daycard，别把 body[data-day]、.v514-art[data-day] 算进去；判定改 n===cards.length")
        print("  6) 左缘尖箭头 → 删掉 </script> 后那个游离的 > 字符")
        print("  7) 改完再跑一次：python scripts/verify_roadbook.py --html 路书.html")
        return 1

    print("PASS 可以交付：%d 个板块、%d 张日卡、详情页/图片/导航/版本/美食分类全部过闸门。" % (len(ids), cards))
    return 0


if __name__ == "__main__":
    sys.exit(main())
