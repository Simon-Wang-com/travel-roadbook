# 框架结构对照文档（旅行路书）

本文是 `assets/template.html` 的权威结构说明，用于生成新路书时**逐项核对**：只改内容、不改框架，确保「不多了、不少了」。

## 1. 页面骨架：12 个 view（section）

| 顺序 | id | 板块 | 说明 |
|---|---|---|---|
| 1 | `v-home` | 首页 | 大标题、天数/人数/人均、4 个入口 tile（准备/行程/预算/其他问题）+ 微信在线版提示 |
| 2 | `v-prep` | 出发前的准备 | 禁带物品、天气、穿搭、出门清单、住宿导航、闹钟日历、餐厅预约 |
| 3 | `v-itinerary` | 行程路线图 | 按天 tab（Day1–4）、每日封面、时间线、票据卡片、当日费用、雨天备选 |
| 4 | `v-faq` | 其他问题 | 为什么这么排、交通行李核算、预算票务、来源与版本 |
| 5 | `v-planb` | 备选方案 | 雨量判断、按天替代路线、砍/留清单、6 类应急 |
| 6 | `v-food` | 餐厅推荐 + 美食打卡 | 按餐次餐厅 + 顺路/本地/景点三个 tab 的美食卡片 |
| 7 | `v-spots` | 打卡地点指引 | 按机位查看，每个机位含小红书/高德/官方图/构图简图 |
| 8 | `v-maps` | 四张可点景区地图 | 自绘点位动线图，点位可点导航 |
| 9 | `v-fuzimiao` | 步行导航图 | 夫子庙—老门东地面步行示意（示例，可按城市替换） |
| 10 | `v-budget` | 预算与费用 | 4 人共享记账（记一笔/结算/累计账目）+ 预算明细 |
| 11 | `v-official` | 官方景区导览图 | 4 张官方原图内嵌，断网可看，附「查看原 PDF」 |
| 12 | `v-ocr` | 票据识别 | 上传票据 OCR + 粘贴文字解析 + 剪贴板 + 4 人座位 |

底部还有固定 Dock（准备/行程/打卡/记账 4 个图标），`data-dock` 与 view 对应。

## 2. 功能清单（对照原版，缺一不可）

### 交通票据（a）
- 上传车票/机票截图 → OCR 自动识别（`api.ocr.space`，免费 key `helloworld`，约 5–10 秒）。
- 也支持：粘贴订单文字「⚡自动填入」、读剪贴板、手动填表、重新识别、清空。
- 3 段车次（D100 动卧 / G7626 高铁 / G735 高铁）+ 1 段航班，各带 4 人座位明细（车厢/座位/席别）。
- 车型识别（`meta(no)` + `DB`）：车次首字母只定等级（G 高铁 / D 动车 / C 城际 / Z 直达特快 / T 特快 / K 快速 / S、Y 市域旅游），品牌（复兴号 FUXING / 和谐号 HEXIE）只认 `DB` 里已核实的车次；未入 `DB` 的 G/D/C 显示「… · 车型待核」，**不得默认标复兴号**。列车图标 `trainIcon(brand)` 按品牌配色（红金/蓝/中性灰）。
- 识别后座位人数自动同步。

### 跳转链接（b）
- 高德导航：`https://uri.amap.com/search?keyword=…&callnative=1`（手机唤起高德）。
- 景区官方导览图：内嵌 base64 + `data-nav="v-official-…"`；附官网/PDF 原文链接。
- 小红书：`xhsdiscover://search/result?keyword=…`；微信内不可直接跳 App 时提示「在浏览器打开」；另有「📋 复制关键词」兜底。

### 板块（c）
- 美食打卡：`🍜 顺路美食 / 🥢 本地美食 / 📸 景点打卡` 三个 tab，卡片含人均、由来、代表餐厅、小红书/导航。
- 打卡地点指引：按机位卡片（时间窗、机位、构图简图、小红书/导航/官方图）。
- 记账：4 人共享记账（记一笔/结算/累计账目），成员应付/已付/结算状态，localStorage 持久化。
- 预算明细：分类明细（人均）+ 每天现场零花 + 待核项。

### 图片（d，重点）
- 构建期出图链路（V6.01）：`scripts/fetch_spot_photos.py`（360/Bing/百度/维基，带标题闸门）→ `photos.json` + `preview/` → `scripts/embed_photos.py` 合并进 `V543_IMGS` / `V600_ALIAS`。运行时只兜底，不承担出图。
- 行程顶部景点封面：`findSpot(title)` 自动识别主景区 → `ORIG`/`IMGS` 内嵌实拍图 → `fetchSpotPhoto()` 联网（维基 REST + 维基搜索，超时 3.2s/候选、单景点 12s 封顶）→ **都没有就中性占位 + 「暂无实拍图 · 名」，不再回退程序化 SVG**（V6.00）。
- 景点打卡·热度榜：每行由 `v600-photo-js` 注入 `.v46-shot` 横幅实拍图，图源 = `V543_IMGS[V600_ALIAS[名]]→k` → `localStorage` → 联网；无图显「无图」。**程序化相框 `.v46-rank::before` 已关掉**。
- 美食配图：`FOOD_RULES` 按名称归类 → 程序化 SVG；V5.64 再加 `v564-art-js` 场景引擎（「菜名 + 所在景点」双重识别 → 九类地貌 + 十二类器皿 + 菜名哈希微调，写 `--v564-fimg/--v564-mimg`；`--v564-simg` 自 V6.00 起作废）。
- 角标：已收录=无角标；**「暂无实拍图 · 名」= 这个景点没配图（必须补）**；联网成功=「网络图 · 名」；「自动题图」已随 V6.00 删除。

### 动画与适配
- 覆盖式转场（body `v512-slide`）、液态玻璃 Dock、每日封面照片→像素→玻璃字幕分层、`prefers-reduced-motion` 降级、暗色主题、移动端/桌面双端响应式、微信内打开降级提示。

## 3. 需要改的数据对象（生成新路书时）

| 对象 | 位置 | 内容 |
|---|---|---|
| `<title>` / hero 文案 | 顶部 | 行程名、日期、人数、人均 |
| `window.V543_IMGS` | 首个 `<script>` | 景点 id → base64 封面图（可选，建议用 `image_search` 抓图填充） |
| `SPOTS` | 主脚本 | 景点 id/名/别名 `a`/官方图 `nav`/`navText`；换城市就换这里 |
| `CITIES` / `LANDMARKS` / `TYPE_RULES` | 主脚本 | 通用地名识别词库，一般不用动（跨城市已较全） |
| 餐厅数据 `rests:[[…]]` | 主脚本 | 每餐餐厅名/人均/来源/城市 |
| 记账/预算默认值 | `v-budget` | 人均、分类明细、待核项 |
| 天气/穿搭/清单/闹钟 | `v-prep` | 按新行程重写文案与日期 |
| 行前必读（一句话路线 / 三条硬提醒 / 行前三件事） | `v-prep` 第一张卡 `v63-readfirst` | 换行程必须整段重写；**不要挪回首页**（见 4.6） |
| 这份路书怎么用 | `v-faq` 第一张卡 `v63-howto` | 一般是框架级说明，换行程只微调「入口叫什么」 |
| 微信在线版链接 | `v-home` `#wechatTip` | 示例里的原版 URL，**新路书要删掉或换成自己的分享链接** |

## 4. 不得改动（框架层）

- 全部 CSS 变量、动画 keyframes、转场/Dock 逻辑。
- `paintHero` / `fetchSpotPhoto` / `cover` / `findSpot` / `typeOf` / `matchDict` / `guessName` 等图片与识别逻辑。
- 票据 OCR、粘贴解析、记账、小红书/导航跳转等 JS 交互逻辑。
- view 结构与 id（`v-home`…`v-ocr`）。

## 4.5 三处已修视觉/布局（实测回归点，勿回退）

| 位置 | 现行规则 | 回退后会怎样 |
|---|---|---|
| Day 封面 | `.dayhero{border-radius:22px}` + `.dayhero .dimg{border-radius:22px}`；`.daybody{margin-top:8px;border-radius:22px}` | 曾被写成 `border-radius:22px 22px 0 0`，封面左下/右下是直角，与顶角不一致 |
| Day 正文顶部 | `html body #v-itinerary .card.daycard .v50-dayart{display:none!important}`；主题图只走底部 `.v514-art`（`.v514-themed` 的 `padding-bottom:152px` 留位）；`placeArt()` 遍历全部 `.daycard`，`data-day` 超过 4 时按 `((d-1)%4)+1` 循环复用插画 | `.v50-dayart` 是 `top:-18px;height:148px` 的顶部装饰带，会盖住 linkrow 和第一个时间点（「06:40 稻城早餐」压图）；`placeArt()` 曾写死 `for(d=1;d<=4;d++)`，第 5 天起不处理，装饰带直接露出来 |
| 交通插画 | **列车图已整块删除**：`html body #v-itinerary .card#railCard::before/::after` 与 `.foldbtn[data-seg]::before` 全部 `display:none!important`；`#railCard` 同步 `min-height:0;padding-bottom:18px`（原来是 `min-height:300px;padding-bottom:120px`，为插画留的位）。**客机图保留**：素材固定用原版场景图 `--v511-plane-scene` / `--v514-plane`（`viewBox="0 0 900 300"`，天空+客机+站台），`#planeCard::before` 末尾兜底写成 **3:1 贴底盒**（`left:0;right:0;bottom:0;height:0;padding-top:33.3333%` + `background-size:100% 100%` + `center bottom`） | 删图不收回 `padding-bottom:120px` → 卡片底部留一块 120px 空白；列车图若复活，105% 概率又被压成「一条红带」（①`100% 100%` 落在非 3:1 盒子上（`.tkcard::before` 的 `height:92px`）；②盒子比图矮，92px 装 137px 的图 → 天空和车窗带被裁） |

## 4.6 首页与内容落点 / 景点打卡指引（写死，勿回退）

| 规则 | 现行做法 | 回退后会怎样 |
|---|---|---|
| 首页只放 hero + 4 磁贴 | `#v-home` 只有 `.hero`（标题/日期人数人均/tag/自定义背景）+ `#wechatTip` + `.tiles` 四个入口。**「一句话路线」「三条硬提醒（先看这三条）」「这份路书怎么用」「行前三件事」一律不许出现在首页** | 历史路书把这些正文块塞进首页，首页被撑成第二张行程页，且和「出发前准备 / 其他问题」重复 |
| 提醒类内容的落点 | `#v-prep` 第一张卡 `<div class="card v63-readfirst">`（tab「📌 行前必读」，默认展开）：一句话路线 + 三条硬提醒 + 行前三件事三个 `.box`；`#v-faq` 第一张卡 `<div class="card v63-howto">`（「📖 这份路书怎么用」） | 没有落点时生成方就会往首页塞；或塞进 `#v-prep` 末尾，用户翻不到 |
| `#v-prep` tab 映射 | `pc=getElementsByClassName('card')` 序号：`pc[0]` 行前必读 / `pc[1]` 违禁物品 / `pc[2]` 天气 / `pc[3]` 穿搭 / `pc[4]` 出门检查 / `pc[5]` 酒店导航 / `ph[0]+pc[6]+pc[7]` 预约提醒；`buildTabs(...,0,'全部')` | 插卡不同步改 `els:[pc[n]]` → tab 点开是空白或串台（点「天气」出来「穿搭」） |
| 景点打卡指引 | 时间线 `.tl>li .c` 里插 `<a class="spotlink" href="javascript:void(0)" data-nav="v-spot-<k>">📸 景点打卡指引</a>`（在 `<em>` 之前）；`markSpotLinks()`（与 `findSpot` 同 IIFE）在加载后 + 1200ms 各跑一次兜底：命中 `findSpot(text)`、`#v-spot-<k>` 面板存在、行内无 `.spotlink`、行内无 `.foodlink` → 补芯片；**同一张日卡同一景点只补一次** | 只剩美食打卡芯片、景点行没有（用户实测就是这个问题）；或每行都补成同款按钮，一排三行重复 |
| 景点 > 美食 的视觉层级 | `html body a.spotlink`：填色深绿渐变 `#12A99A→#087569`、白字 12px/800、27px 高、白色相机圆标、投影；`::after{content:"景点打卡指引"}`。`.foodlink` 保持浅橙描边 `#fff7ed`/`#fed7aa`/12px | 旧 `.spotlink` 是 11px 白玻璃小胶囊，比美食芯片还弱，用户分不出哪个是重点（新样式必须 `html body` 提权 + `!important` 才能压过旧规则） |

## 4.7 交付必须带二维码（死规则）

- 交付物是**两张**：`xxx.html` + `二维码.png`，缺一不可。二维码指向 `FileBatchUpload` 上传后拿到的 `https://` 链接（实测该链接返回 `Content-Type: text/html`，手机扫码直接渲染路书，不是下载文件）。
- 生成器：`scripts/make_qr.py`（用 `segno`：纠错 M、静区 4 模块、≥400×400 px、纯黑码点 + 纯白底）。缺依赖就 `python -m pip install segno`；彻底断网时换任意离线 QR 库，**「必须给码」这条不放松**。
- `file:///` 路径不许拿来生成二维码（手机扫了打不开）。
- `#wechatTip` 里内嵌的那张示例二维码（杭州南京在线版）必须换成这次的分享链接，否则微信里扫码会打开示例路书。

## 4.8 V5.64 层：配图重绘 / 返回条 / 三态可读性 / Dock / 背景模糊（写死，勿回退）

模板末尾追加了 5 个带 id 的块（都在 `</body>` 之前，纯追加、不改上方任何代码）：

| 块 | 作用 | 关键实现 |
|---|---|---|
| `v564-art-css` | 让新变量压过旧图 | `html body .v46-food[data-v46-rest][data-v564]::before{background-image:var(--v564-fimg)!important}`（热度榜 `--v564-simg`、餐次磁贴 `--v564-mimg` 同理） |
| `v564-art-js` | 场景插画引擎 `window.V564ART` | `h32()` 菜名哈希 / `rr()` 确定性伪随机 / `PAL` 9 套配色 / `kindOf()` 九类地貌 / `motif()` 远景 / `catOf()` 十二类器皿 / `dishP()` 器皿绘制 / `food(name,spot)` / `spot(name)`，输出 96×96 SVG dataURL |
| `v564-bind-js` | 把每张卡绑到它自己的景点 | `harvest()` 收景点名（去 emoji / 去 `· 副标题` / 去 `11/22` 日期尾巴 / >16 字丢弃）→ `spotOf()` 最长命中 → 兜底 `regionOf()`（最近的 h3 地区）→ 写 `--v564-*` + `data-v564-spot`；1.2s/2.4s/4s + 点击后 + `MutationObserver` 重绘 |
| `v564-fix-js` | 返回条 / Dock 滑块 | 机位 `section.view[id^="v-spot-"]` 注入 `.v564-backbar`（`← 返回上一级` 回进入前的板块、`✕ 关闭` 回 `v-itinerary`，`data-v564-back` 幂等）；点 Dock 首页当下把液滴推到首页槽位并保 1.6s 不被 `hidden`。**背景预模糊（`--v564-bg-soft`）已整块删除**——它会把壁纸糊掉，且正是「深色看不见背景」帮凶之一 |
| `v564-fix-css` | 三态可读性 + 徽标布局 + 液滴过渡 | 深色 `.box/.b-gray/.b-ok/.b-warn/.b-bad/.b-info` 实色深底亮字；`body.hasbg` 下 `.box` 近不透明白底深字；`#dayTabs .ptab{flex:0 0 auto;min-width:max-content}` + `.todaydot{margin-left:8px}`；`#dockLiquid` 加 `opacity .22s`。徽标配色见 `v586-addon-css` |

实测数据（无头 Edge 取证，`--dump-dom` 读计算样式）：

- Day 标签：`tab.w=121 / dot.w=51 / dot.dx=56 / position=relative / margin-left=8px`（改前 `116 / 49.1 / static`）。
- 深色 `.box.b-gray`：`color:rgb(228,241,239)` + `linear-gradient(158deg,rgba(26,44,48,.94),rgba(15,29,33,.92))`（改前是浅灰底 + 浅色字，读不出来）。
- Dock：点首页后 `transform` 从 `210px` → `27.3px`（首页槽位），`className` 始终 `v44-liquid`（无 `hidden`），到 +700ms 仍 `opacity:1`（改前 0 帧就 hidden）。
### V5.91：封面图从背景图换成 `<img decoding="sync">`

转场结束时 `#v-itinerary` 由 `fixed/z41/will-change:transform` 回到 `static`（实测 t≈448ms），整页重栅格化 → 背景图重新解码 → 解到一半的画面被先画出来（第 85 帧整块糊）。

处置：`.dayhero .dimg` 里注入 `<img class="v591-photo" decoding="sync">`（`object-fit:cover`、`border-radius:inherit`、`pointer-events:none`），onload 成功后把 inline 背景置 `none` 兜底路径保留给 JS 异常。实测 8/8 图 `complete=true`、背景全 `none`、整屏截图 `mean diff 0.36`。

与 v590 的关系：v590 治“渐进式先出低清扫描”，v591 治“解码中间态被画出来”，两条都要在。

### V5.90：内嵌图从渐进式改为基线式（治「景点图糊一帧」）

录屏逐帧证据：第 85 帧封面区整块变糊（亮度 118.9→181.1），第 86 帧复原；文字始终清晰。根因是**渐进式 JPEG 解码的第一遍扫描**：图被丢弃重解码时先画整幅低清版。

处置：模板与路书里 14 张 `data:image/jpeg` 大图全部重编码为 `progressive=False`、长边 ≤1200、quality 82；换图前后整屏截图 `mean diff 0.67 / max 44`（无可见损失）。转换脚本思路：正则抓 `data:image/jpeg;base64`（≥40KB）→ `Image.open` → `exif_transpose` → 超长边缩到 1200 → `save(progressive=False, optimize=True)` → 回填 base64。

约束：新增或替换任何内嵌图，都必须走这条规则，否则封面会在重解码时糊一帧。

### V5.89：行程页封面图/主题插画层的稳定化

排查事实（进行程页静置）：`#v-itinerary` 子树 6s 只有 40 条 `childList`、零 `style/class/src` 变更；`document.head` 8s 零 mutation；排版几何（`hero.top` / `hero.height` / `card.height`）352 帧单值。周期性重建的只有站点自己的 `v44-plane-head`、`foldbtn`（~1.6s）与 `tkIco/tkNo/tkModel/tkGate/tkSeats`（~2.0s）文本节点。

对策与实现位置（都在 `</body>` 前的追加层里）：

| 项 | 写在哪 | 作用 |
|---|---|---|
| 封面图独立图层 | `v589-addon-css`：`html:root .dayhero .dimg{transform:translateZ(0);backface-visibility:hidden}` | 兄弟节点重排不再重画照片 |
| 主题插画独立图层 | `v589-addon-css`：`html:root #v-itinerary .card.daycard .v47-dayscene{…}` | 该元素是 `.card.daycard` 直接子节点，不是 `.dayhero` 子节点 |
| 轮播层去常驻提升 | `v589-addon-css`：`header .dsl{will-change:auto!important}`（实写在 `.dayhero .dsl`） | 8 天 × 3 张的常驻图层本路书并不存在，去掉无副作用 |
| 预热解码 | `v589-addon-js` | `new Image()+decode()` 把 data URL JPEG 提前塞进解码缓存；`warmed 8 / dimg 8` |
| 预模糊图预热 | `v568` 的 `makeBlur()` 内 | v588 的 `--v568-hero-blur` 首次使用就是转场首帧，必须提前解码 |

边界：无头 Edge 复现不出该闪（静置 41 帧 `diff 0.0`；切 Day 48 帧只换天一次；进入转场 4 帧清晰度单调上升 42.97→54.06→56.78）。因此本节是按机理做的稳定化，真机复看才算验收。

- 背景：原图是 PNG 时浮层 `background-image` 里出现 `data:image/jpeg`（= 预模糊图），`body::before` 仍 `blur(4px) saturate(1.04)`。

## 4.9 V5.68–V5.99 层：Dock 下沉 / 背景 / 徽标 / 转场（= 原版线上代码，逐字对齐）

模板在 `</body>` 前追加 8 个块。**本轮口径改了：v570 / v576 两层不是「自己写的动画」，而是从原版线上页（`https://hz-nj-autumn-roadbook.app.workbuddy.host/?sharecode=X75M5S66IP`）整块复制过来的原文**，`v578-addon-css` 与原版字节级一致；自造的 `v584-addon-css`（实色深底 + `#dock.v84sink`）与本轮之前的 V5.84/85 自研下沉机制（`pinDockVisible` / 逐帧内联 `!important` / 480ms 看门狗）**已整块删除**。

| 块 | 作用 | 关键点 |
|---|---|---|
| `v568-addon-css` / `v568-addon-js` | 转场时浮层背景与静止背景一致 | 开始帧把 `body` 的 computed `backgroundColor`+`backgroundImage` 写进 `--v568-bodybg`，浮层用 `var(--v568-bodybg)` |
| `v569-addon-css` / `v569-addon-js` | 液滴不硬切 | 给 `#dockLiquid` 补 `transition:opacity`；转场期强制液滴可见 |
| `v570-addon-css` / `v570-addon-js` | 时长拉齐 + 落地释放（**原版原文**） | `#dock{transition:opacity var(--v570-dur,.42s) linear, transform var(--v570-dur,.42s) ease}`；`releaseDock()` = 钉 `opacity:1` → reflow → 两帧 rAF 后放 `0`，**位移与曲线交给 CSS** |
| `v576-addon-js` | 液滴归位 + `sink()`/`unpinDock()`（**原版原文**） | 点击捕获阶段算槽位写 `translate3d`；回首页用 `data-v58="hold"→"sink"` 两条 CSS 规则承载下沉（`.30s` / 终点 `translate3d(0,96px,0)`）；落板块 `unpinDock()` 交还站点 |
| `v578-addon-css` | 深色壁纸 + 底部灰白条 | `body.hasbg{background:transparent!important}`；`::before` 与 `::after` 同步 `inset:-34px`；深色纱幕 `rgba(6,14,17,.18→.34)`；`body.hasbg.dark` 同构分支 |
| `v589-addon-css` / `v589-addon-js` | 行程页封面图稳定化 | 见下节 V5.89 |
| `v586-addon-css`（本轮新增） | Day 徽标配色 | 基础态白字 + 白点；`.is-wait` = `#7A2E12` on `#FFEFD8`（字 ≈8.6:1）+ 圆点 `#B23A00`（≈5.1:1） |
| `v587-addon-css` | reduce-motion 下保留下沉 + 壁纸合成层 + lvh 几何 | 见下节 (A)(B) |
| `v588-addon-css`（+ `v568` 内 `makeBlur`） | 转场浮层壁纸改预模糊位图 | `::after{background-image:var(--v568-hero-blur); filter:var(--v588-after-filter)}`；JS 在应用壁纸时 canvas 模糊一次 |
| `v587-addon-css` + `v568` 的 `setVar` 守卫（本轮新增） | 真机两条复现问题 | ①reduce-motion 下保留下沉 ②壁纸提升合成层 ③`100lvh` 锁几何 ④`syncHero` 写前比对，断掉自激重绘 |
| `v594-addon-css` | 自定义背景浮层必须不透明 | 纱幕+预模糊壁纸画在浮层自身 `background`，兜底 `#f4f7f6`，停用两个伪元素 |
| `v595-addon-js` | 两层壁纸几何一致 | 写 `--v594-bg-size`（等效像素尺寸），浮层 `background-size:auto,var(--v594-bg-size,cover)` |
| `v596-addon-css` + `makeBlur` | 壁纸模糊降到 **0**（14→4→2→0） | `saturate(1.05)!important`（深色 +`brightness(.95)`）；`blCss=0`，画布只缩放 |

| ~~`v597` / `v598`~~ | **已整块删除**（「浮层上再画一层壁纸」这条路线作废） | 见下节 V5.99 |
| `v599-addon-css` | 转场浮层「什么都不画」，背景只由静态层呈现 | `body.hasbg .view.v512-in{background:transparent; background-image:none}` + 两伪元素 `content:none` + `body.hasbg .view.v512-out{opacity:0; transition:opacity .16s}` |

**下沉：与原版线上页的同链对照（CDP 真实时间，520×900，脚本：点首页磁贴进板块 → 点 Dock「首页」）**

| 采样 | 线上原版 | 本模板 |
|---|---|---|
| 转场结束 t=480ms | `data-v58=hold`，inline `opacity:1` | 同 |
| +60ms | op .944 / translateY 3.72px | op .778 / 33.17px |
| +120ms | op .722 / 44.99px | op .556 / 71.14px |
| +180ms | op .500 / 77.06px | op .389 / 85.68px |
| +240ms | op .277 / 91.23px | op .167 / 94.41px |
| 收敛 | op 0 / 96px | op 0 / 96px |

同一条 `transition .30s`、同一终点 96px → 肉眼是「整条胶囊沉出屏幕并淡掉」。**验收必须用 CDP 实时驱动（websocket + `Runtime.evaluate` + `awaitPromise`）**，无头 `--virtual-time-budget` 下站点落地依赖动画 `finished`，`v512-slide` 永不撤 → `releaseDock()` 根本不触发，看起来像「没有下沉」，那是取证假象。

**背景两条实测（`--force-dark-mode` + 注入 `hasbg`，520×1700 整页截图）**：深色下 `body` 背景为 `transparent`、壁纸整屏可见、`::after` 为深色暗罩；首页磁贴下方不再出现灰白矩形（改前 `::before -26px` / `::after 0` 差一圈 + 磁贴刷实色深底把壁纸盖住）。

**三条不许回退的约束**：

1. 不许给 `#dock` 再套 `Element.prototype.animate`，也不许在 rAF 里逐帧写内联 `!important`——原版是纯 CSS 过渡，抢属性就会变成「一帧消失」。
2. 不许删 `#dock` 基础规则里的 `transform:translateY(18px) scale(.96)`（删了只剩淡出，没有下沉）。
3. 不许再给 `body.hasbg` 加 canvas 预模糊层，也不许把 hero / 磁贴刷成实色深底去「压住背景」——那会把壁纸整块盖掉。

### V5.87：两条只在真机上复现的问题

**(A) 手机开「减弱动态效果」→ Dock 一帧消失。** 压制链三条叠加：`@media (prefers-reduced-motion:reduce){#dock{transition:none}}`、全局 `*{transition-duration:.01ms!important}`，以及 reduce 分支里优先级最高的 `html body:not(.v512-slide) #dock#dock{transition:none!important}`。`v587-addon-css` 在同一媒体查询里用 `html:root body:not(.v512-slide) #dock#dock`（多一个 `:root` 伪类）把优先级抬到 (2 id,2 class,2 type)，并只写标准 `transition` 简写、时长为字面量。

实测（390×844 + DPR2 + 真实触摸 `Input.dispatchTouchEvent`）：正常态 `transitionDuration=0.3s,0.3s`，曲线 `1.000 → .833/21.2px → .667/55.3 → .445/81.8 → .167/94.4 → 0/96`；reduce 态修复前 `0s` 且 `1.000 → 0.000/96px` 一帧跳，修复后 `.944/3.69 → .722/45.0 → .500/77.0 → .333/88.8 → .111/95.3 → 0/96`。**踩坑：这条覆盖里出现 `-webkit-transition` 前缀简写会让正常态变成「位移在动、透明度直接归零」，必须只留标准属性。**

**(B) 自定义背景「时不时抽动」。** 根因是 `v568-addon-js` 的 `syncHero()` 挂在 `documentElement` 的 `style` 属性 MutationObserver 上，而它自己又往 `documentElement.style` 写 `--v568-hero-img`（整段 base64）与 `--v568-bodybg` → 写一次触发监听、监听再写一次，样式失效与重绘永不收敛。修法是写前比对现值（`setVar()`）。实测 390×844、真实照片 900px、只 `setProperty('--hero-bg')` 一次：空转 10s 的 `setProperty` 次数与 `style` 属性变更次数均为 **0**（修复前持续不停），壁纸区 12 帧帧差逐帧 `mean=0.00`。

同层还有两条防御：`body.hasbg::before{will-change:transform,filter; transform:translateZ(0) scale(1.05)}`（独立合成层，滚动时不重算 `blur(6px)`）；`@supports (height:100lvh)` 下两层几何钉成 `top:-34px; height:calc(100lvh + 68px)`（地址栏收展不再改变 `cover` 裁剪）。

**验收边界**：CDP 的 `Emulation.setDeviceMetricsOverride` 中 `lvh === vh`，无头环境无法复现地址栏切换的 `lvh≠vh` 差异，只能证明规则已生效；真机是否彻底不抖需用户实测。另外做「抽动」实验必须用真实照片、且 `--hero-bg` 只写一次——探针里 `setInterval` 每 400ms 重刷会污染写入日志，把探针自身行为误判成站点行为。

### V5.88：切换「准备 ↔ 行程」时的闪烁与掉帧

**成因不是站点，是我上一轮自己加的 animate 包装**（`wrappedAnimate` 装到 `Element.prototype.animate`：暂停 4 帧预热 + 尾部 30% 保持帧 + `commitStyles()` 后 `cancel()`）。390×844 逐帧 transform：

- 包装在：`390px` 保持到 ~108ms → 141ms `250` → 179ms `83` → 207ms `24.9` → 241ms `5.6` → 274ms `0.4` → 308ms `0`，再停 230ms 才 `none`。即「先卡住 ~130ms（新页停在屏外），再 170ms 猛冲进来」。
- 包装停用：`390` → 78ms `337` → 112ms `239` → 145ms `161` → 179ms `105` → 211ms `66` → 245ms `40` → 278ms `22` → 311ms `10.8` → 345ms `3.9` → 378ms `0.6` → 412ms `none`。
- 线上原版同链（`cdp_orig_cmp.py`）：只有 `[opacity .9 + translate3d(0,7px,0)]→[...] 170ms` 与 `[translate3d(±100%,0,0)→0] 260ms` 两条 WAAPI，无包装。原版在无头里开头也有 ~100ms 不动，那是首次合成的采样延迟，两边一致；差别在包装额外加了尾部保持帧与 cancel 抢帧。

同层一起停用的还有 `②-C 落地帧禁过渡`（`v568-land`，落地 60~80ms 把 `.view` 的 `transition` 置 `none`，与撤 `.v512-in` 抢同一帧 → 硬切）。

另修一处掉帧源：浮层壁纸 `.view.v512-in::after` 原为 `position:fixed + filter:blur(4px)`，但它位于正在 `translate3d` 的浮层内，`fixed` 退化成随层移动 → 260ms 里每帧重做整屏高斯模糊。`v588` 用 canvas 预模糊一次（`--v568-hero-blur`，同 `blur(4px) saturate(1.04)`），`--v588-after-filter` 置 `none`；实测转场期 `::after{filter:none, background-image=28,326 字符}`。用户录屏 `f055`/`f097` 的「整页糊一帧再变清晰」即此。

**不许回退**：三处安装点（`Element.prototype.animate = wrappedAnimate;`、`Animation.prototype.cancel = wrappedCancel;`、`classList.add('v568-land')`）都必须保持注释/停用状态。


### V5.92：关掉「Day 1 胶囊 / 日期标签条」的实时背景模糊

**症状**：首页→行程，顶部景区图整卡糊一帧；美食/记账→行程，只有 `Day 1` 胶囊那一条糊一帧。

**帧证据**（576×1280、30fps）：f38 变化区 y 401–1177（整卡）、f107 变化区 y 401–681（只有标签条+胶囊），两帧都是"单帧闪"，照片以下段落差为 0。

**根因**：`.daychip{backdrop-filter:blur(12px) saturate(1.7)}` 与 `.ptab{blur(8px) saturate(1.65)}` 是唯二带背景模糊的元素；`backdrop-filter` 要实时抓背景纹理，转场落地重栅格化后纹理作废，重抓那一帧即为糊帧；含该子元素的 `.card.daycard` 还会被提升为背景根，于是整卡一起糊。

**修法**：`v592-addon-css` 用 `html:root` 提权把两处 `backdrop-filter` 置 `none`，`.daychip` 改静态深底 `rgba(8,20,26,.74)` + 内高光描边。

| 块 | 作用 | 关键点 |
|---|---|---|
| `v592-addon-css` | 关掉胶囊/标签条的实时背景模糊 | `html:root` 提权 + `backdrop-filter:none!important`；胶囊改静态深底；未选中标签补 `rgba(255,255,255,.55)` 淡底 |

验收：`backdrop-filter` 计算值 `none`；整页截图差 `mean 0.39`、胶囊区 `4.16`，无视觉回归。

### V5.94：自定义背景下转场浮层透明 → 上一版块透出来（v593 已撤回）

**症状**：只有在自定义背景（`body.hasbg`）下，切换板块时上一版块会叠在下一版块下面；首页点行程时页面像"自己在滑一段"。

**根因**：`v568` 把浮层底色写成 `--v568-bodybg`，而 `body.hasbg` 的 computed background 是 `transparent`；垫底靠 `::after`（壁纸，`z-index:-2`）与 `::before`（纱幕，`z-index:-1`）两个负 z 伪元素，真机合成会把它们排到浮层之外 → 底下那页透出来；浮层内部又在对齐 `scrollMemo`，透明叠加就成了"自己滑"。

**修法**：`v594-addon-css` 把「纱幕 + 预模糊壁纸」画到浮层自己的 `background`，给不透明兜底色 `#f4f7f6`，停用两个伪元素；深色同构（`#101c1e` + 暗罩）。

**同时撤回 v593**：滚动位置记忆是站点的既有功能，用户明确要求保留。

| 块 | 作用 | 关键点 |
|---|---|---|
| `v594-addon-css` | 自定背景转场不透明 | `html:root body.hasbg .view.v512-in` 提权 + 不透明兜底 + 纱幕/壁纸画在自身；伪元素 `content:none` |

验收：切换瞬间 `backgroundColor` 由 `rgba(0,0,0,0)` 变 `rgb(244,247,246)`；记忆复测 534→回首页→534 保持不变。
### V5.95：自定义背景下转场壁纸「短暂变形」

`body::before` 的等效尺寸 = `(视口+52px) × cover × scale(1.05)`；浮层 `.view.v512-in` 过去用 `cover` 铺满视口，比静态层小约 12%，转场 260ms 内壁纸被压小、落地才弹回 → 「变形后恢复」。

修法：JS 算出静态层等效像素尺寸写 `--v594-bg-size`，浮层 `background-size:auto,var(--v594-bg-size,cover)`。像素证据：转场中/静态 网格间距 16.3 : 22.7 → 修后 89.8 : 89.8。

| 块 | 作用 | 关键点 |
|---|---|---|
| `v595-addon-js` | 对齐两层壁纸几何 | 读 `body::before` 的 width/height+transform、读 `--v568-hero-img` 尺寸算 cover，写 `--v594-bg-size` |

### V5.96 → V5.99：自定义背景下的转场（最终答案：浮层什么都不画）

前四轮（v594 不透明底 / v595 几何对齐 / v596 模糊对齐 / v597 纸层钉住 / v598 同源绘制）都是同一个思路：**在转场浮层上再画一层壁纸**，再想办法让它「看起来没动」。用户第 6 次复测的两条症状正说明这条路到头了：

1. **白幕**：行程下滑 → 切美食 → 切回行程，背景先被一层近白色盖住再消失。那层白就是浮层兜底色 `#f4f7f6` —— 纸层在真机上没按时建起来（`--v568-hero-img` 空 / Observer 晚一帧 / 媒体查询或 `isDark()` 分支不命中）时它就露出来。
2. **背景左右滑**：纸层晚到、或每帧 `--v596-px` 反向位移滞后于站点 WAAPI 的 tx，壁纸就跟着页面滑。

两个症状同源：**背景的正确性依赖运行时图层「按时到位」**。

v599 的做法是把这个依赖彻底去掉：转场期浮层不画任何东西，屏幕上只保留 `body.hasbg::before` 这一层壁纸（`position:fixed`、不在任何 `transform` 祖先里 → 不可能被盖、不可能位移）。旧页内容改为 160ms 淡出，既避免旧页从新页卡片缝隙里透出（v594 治过的老问题），也避免新页未入场时的整屏空白。

| 块 | 作用 | 关键点 |
|---|---|---|
| `v599-addon-css` | 转场期背景绝对不动 | 浮层 `background:transparent`、两伪元素 `content:none`；旧页 `opacity:0` + `transition:opacity .16s`；一个 JS 都不加（`v597-addon-js` 已删除） |

验收（真实点击，非合成浮层）：转场期 `.view.v512-in` 的 `backgroundColor` = `rgba(0,0,0,0)`、`backgroundImage` = `none`；`.view.v512-out` 的 `opacity` 1 → 0.69（t≈60ms） → 0（t≈160ms）；t≈400ms `v512-slide` 撤、正常落地；页面上不存在 `.v596-paper`。

**为什么必须用重复类名**：浮层壁纸是伪元素，`v568`(0,4,2) / `v578`(`body.hasbg:not(.dark)` 与 `body.hasbg.dark`，0,5,2) 层层加成，`content:none` 写普通特异性只会压住第一条。v599 写成 `html:root body.hasbg.hasbg .view.v512-in.v512-in`（(0,6,2)）+ `background:none` + `filter:none`。

**实测对照**（同一真实点击：行程下滑 520 → 美食）：v598 浮层 `backgroundColor = rgb(244,247,246)`、`::after content:""` 且随 `tx` 390→290 移动；v599 浮层 `rgba(0,0,0,0)`、`::after content:none`、`backgroundImage:none`。

代价（必须接受）：观感从「旧页停在原地被盖住」变为「旧页内容淡出 + 新页滑入」。深色 + 自定义背景走同一条规则，不再有「深色分支未同构」的遗留。

## 4.10 V6.00：景点图只允许实拍（用户硬规则，勿回退）

用户连续两轮的口径：①「之前有个版本点进景点打卡界面也是能显示景点图片的，是把这个功能删掉了吗，要补上」②「行程版景点展示不是实图，而是这种 AI 生成的图，我要求的是能自动识别当日主要景点并且联网搜索抓图片展示」。V5.64 那套「按景点自动重绘」正是"图二"的来源——程序化 SVG 被当成了景点图。V6.00 把它拆开：**景点=实拍，美食=程序化**。

| 块 | 作用 | 关键实现 |
|---|---|---|
| `v600-photo-css` | 关掉压在照片上的程序化层 + 给占位和缩略图定样 | `.daycard .v47-dayscene{display:none!important}`、`.dayhero .dimg.v600-noph`（深绿渐变占位）、`.v46-rank::before{content:none}`、`.v46-shot`（92px 整行横幅、`order:-1`、`flex-wrap`） |
| `v600-photo-js` | 给热度榜每行补实拍缩略图 + 兜底换掉残留 SVG | `aliasKey()`（精确 → 行名包含别名）、`pick()`、`cg/cp`（`localStorage` 键 `v600s:<名>`）、MutationObserver 监听 `.v46-rank` 新增 |
| `v543-js` 内 `fetchSpotPhoto` | 图源顺序改成「内嵌优先」 | `IMGS[spot.k] → IMGS[名] → IMGS['s:'+名] → IMGS['n:'+名]`，再 cache，最后才联网；候选串 = 原名 / 按 `·、/,` 切片 / `sub` / 去后缀；单景点 12s 封顶；新增维基搜索接口 `action=query&generator=search&prop=pageimages&origin=*` |
| `v543-js` 内 `applyHeroPhoto` | 多一个回调，让角标能反映真实结果 | `applyHeroPhoto(img,hero,spot,cb)`；`cb(true)` 才写「网络图 · 名」，`cb(false)` 写「暂无实拍图 · 名」 |
| `v543-js` 内 `paintHero` | **删掉 `cover()` 兜底** | `!src` 分支只做：背景置 `none` + `.v600-noph` + 角标「找图中 · 名」→ `applyHeroPhoto(...)`；`cover(spot,i)` 只在 `__v543CoverFor` 里留作工具 |

数据契约：

- `window.V543_IMGS`：key = `SPOTS` 的 `k`，value = `data:image/jpeg;base64,…`（长边 ≤1100、q68、`progressive=False`）。
- `window.V600_ALIAS`：key = 热度榜行名里能出现的景点片段（如 `独克宗古城`、`松赞林寺`、`牛奶海`），value = `IMGS` 的 key。
- 同一景点可多日复用；**不同景点不许共用一张图**。

验收（无头 CDP，390×844，`file://` 打开即可）：

| 检查 | 期望（v600 实测） |
|---|---|
| `.daycard` 封面 | `img.v591-photo` 的 `src` 全是 `data:image/jpeg`；8 天各不相同 |
| `.v543-auto` 角标 | 正常路书里 0 条（无「自动题图」） |
| `.daycard .v47-dayscene` | 全部 `display:none` |
| 点「美食 → 景点打卡」后 `.v46-shot` | 15 条 = `.v46-rank` 15 条，`ok=15 empty=0 loading=0` |
| `.v46-rank::before` | `content:none` |
| 文件体积 | 16 个景点内嵌图 ≈ +3.2MB（路书 4.5MB → 5.06MB），属预期 |

踩过的坑（别再重复）：

- 以为 `V543_IMGS` 是空的：其实路书里原本就内嵌了 11 张高清图（`gz/songzan/duke/jinsha/niunai/luorong/zhenzhu/baita/xindq/zheduo/chengdu`，共 ≈2.8MB）。**改之前先 `json.loads` 解析整块，别用 `index(';')` 截断**——base64 里 `data:image/jpeg;base64` 就带分号，会误判成 39 字节的空对象。
- 以为行程页没图：`.dimg` 的 `backgroundImage` 是 `none`，但实拍图在 `.dimg > img.v591-photo` 里（v591 层把背景换成了 `<img decoding="sync">`）。查图要查 `img.v591-photo`，别只看背景。
- 热度榜行里原本有 `--v543-spimg` / `--v564-simg` 两个程序化相框（`::before` 画的"米色照片占位"），不清掉会和新缩略图叠成两张图。

## 4.11 V6.01：内容整套替换 / 图源构建期脚本 / 滚动锁兜底

这一层解决的是「换个 AI 也能把路书生成对」，三件事：

**1) 示例数据必须整套替换，不许删模块**

模板是从「杭州 + 南京赏秋」那份完整路书改出来的，`var S` / `var F` / `var SPOTS` / 美食三 tab / 机位面板 / 官方导览图 / 预算默认值全是真实可点内容。实测踩过：某个 AI 发现「美食打卡三 tab 里是南京数据」，处理方式是把整个模块删掉、换成静态「按餐次查看」11 页。所以：

- 模板里每个示例数据块前都插了 `/* ===== DEMO 数据：必须整套替换 ===== */`；
- 三 tab 结构是硬功能，只许换数据不许删；
- `scripts/check_demo_leftovers.py` 把这事变成退出码：正文/标题（硬失败）、数据块（硬失败）、代码旧命名（只提示）。

**2) 图源：构建期脚本 + 标题闸门**

运行时抓图在国内已证伪（无 CORS / 被墙），所以主路径固定为构建期内嵌，图源落到脚本：

| 图源 | 构建期 | 备注 |
|---|---|---|
| 360 图片 `image.so.com/j` | ✅ 首选 | CDN 图可直下，标题字段完整 |
| Bing `bing.com/images/async` | ✅ 备用 | `murl` 会混无关图（实测查寺庙返回人物像），**必须**过标题闸门 |
| 百度 `image.baidu.com/search/acjson` | ⚠️ 尽力 | 常返 `antiFlag: Forbid spider access` |
| 维基 REST | ⛔ | 本机 20s 超时 |
| 小红书 / 携程 / 高德 / 美团 | ⛔ | 无公开免鉴权图片检索接口 |

`fetch_spot_photos.py` 的闸门：标题里必须出现检索词（≥2 字），且黑名单（地图/门票/logo/动物/花卉/人像/自拍/特写/壁纸…）直接丢；输出 `photos.json` + `preview/<k>.jpg` 供肉眼复核。`embed_photos.py` 负责把 `photos.json` 合并进 `V543_IMGS`、别名合并进 `V600_ALIAS`，幂等可分批。

**3) 滚动锁兜底 `v601-guard-js`**

`html.lgx-ovlock` / `body.v46-modal` 的 CSS 是 `overflow:hidden!important` + `position:fixed!important`（锁背景滚动用）。转场/弹层状态没同步上时（部分安卓 WebView、微信内置浏览器），这两个 class 会残留 → 「刚打开点进行程页怎么都滑不动」。兜底逻辑：

- 只在 `.v46-ov.on` 不可见且 `#lb.on` 不存在时清；
- 启动 0.8s×15 → 2s 常驻；`[data-nav]`/Dock 点击后 700ms；`visibilitychange`/`pageshow`；`touchstart` 时还锁着立即解；
- 解锁时读 `--lgx-sy` 还原 `scrollY`（先立即滚一次，80ms 后再滚一次，避开 body 从 fixed 回到流里时高度未恢复被夹到 0）。

实测：手动注入 `lgx-ovlock + v46-modal + position:fixed` 后 1.6s 变回 `class='' / static / clip visible`；「行程→美食→行程」后仍能滑（模板 scrollY 385、路书 953）。

## 4.12 V6.02：交付二维码改「卡片式」

用户原话：「返还的二维码太素了，要像这个二维码一样」。参考图是一张竖版卡片：白底圆角卡片 + 深墨绿标题（目的地）+ 灰色副标题（版本 · 扫码提示）+ 深墨绿圆角码点的二维码（三个定位角是圆角方框）+ 底部灰色链接与微信提示。

`scripts/make_qr.py` 重写为（默认即卡片，`--bare` 才出裸码）：

| 元素 | 实现 |
|---|---|
| 画布 | `PAGE_BG #f4f6f5` 上叠 `CARD_BG #fff` 圆角 26 卡片 + `#e2eae7` 1–2px 描边 |
| 标题 | `FONT_BOLD_CANDIDATES`（msyhbd / msyh / simhei / PingFang / Noto）逐级缩放到一行放得下 |
| 二维码 | `draw_round_qr()`：逐模块 `rounded_rectangle(radius=0.22*module)`；三个 finder 单独画「圆角外框 + 白框 + 实心圆角块」 |
| 纠错 | `segno.make(url, error="h")`，圆角与配色靠 30% 冗余兜底 |
| 静区 | 3 模块 |
| 页脚 | 去协议头的链接 + 「微信内若看到旧版，退出重进链接即可」 |

验收：`pyzbar` 回读必须解出原链接；本版在 100%/75%/55%/40% 四档缩放下均通过（`https://aka.doubaocdn.com/s/bF28tyfmAU`）。卡片尺寸随码区走（560 码区 → 688×820）。

## 4.13 v1.2：版本号规则 + 三处「别人的东西」清干净

**版本号规则（用户定）**：对外版本 = 用户要求改 skill 的累计次数，`v{十位}.{个位}`（12→v1.2、9→v0.9、23→v2.3）。压缩包名、页面 `#wechatTip` 的「本页 v1.2」、二维码副标题三处必须同号；记录在 `references/version.md`。代码层编号（v600-photo-js / v601-guard-js）不对外。

**这一轮查出来的三个真 bug（模板从原版继承下来的，都会跟着新路书一起发出去）：**

| 位置 | 问题 | 修法 |
|---|---|---|
| `#wechatTip` | 模板里写着 `https://hz-nj-autumn-roadbook.app.workbuddy.host/?sharecode=…` 和一个二维码图：生成的每本路书都带着**别人**的路书链接，扫了就是别人的页面 | 整块换成纯文字提示（「本页 v1.2 · 已把照片…内嵌…」），链接/二维码由生成方交付时替换 |
| 费用账本 `TRIP/CEP/COA/CPK` | 模板内置 `TRIP='hz-nj-2026'`、第三方云 endpoint、**一个 publishable key**；两份不同行程会写进同一本账（串号），key 也随文件外发 | `TRIP` 改成按 `document.title` 生成；`CEP/COA/CPK` 置空，云端分支加 `CEP&&CPK` 前置判断 → 默认纯本机账本，不连任何第三方 |
| iCal `PRODID` / `UID` | `PRODID:-//Hangzhou Nanjing Autumn Roadbook//ZH`、`UID:…@hz-nj-roadbook`：导出日历里带着示例行程的名字 | 改成 `Travel Roadbook v1.2` / `@travel-roadbook` |

`check_demo_leftovers.py` 也补了英文与 URL 词条（`Hangzhou` / `Nanjing` / `hz-nj` / `workbuddy.host` / `wbpk_`），否则这类残留中文检查根本看不见。

## 4.14 v1.3：景点详情页（打卡指引点进去那一页）补实拍头图

**用户的反馈**：热度榜那行有图了，但点「📷 机位详情」进去，详情页顶部还是空的。原因是 V6.00 只给 `.v46-rank` 行和日卡补了图，**`v-spot-*` 详情页一个图片节点都没有**。

补法：新增 `v13-spotdetail-css` + `v13-spotdetail-js`（追加层，不改原结构），分两种情况：

- 页面里已经有 `<div data-img="key">` 占位（本框架生成的路书都有）：**往占位里填图**，不另插横幅，避免同一张图出现两次；占位原来没图（内嵌缺 key）就填「暂无实拍图 · 构建期未配」。
- 没有占位（实测 Workbody 一类工具生成时会把整块占位省掉，这就是「点进去没图」的真因）：在 `.hero` 下面补一条 `.v600-detail-photo` 实拍横幅（200px，左下角「景点名 · 实拍」角标）。

两种情况取图都走 `__spotPhoto`（内嵌 → 缓存 → 联网），拿不到只写「暂无实拍图」，**不许用插画顶替**。而且只在页面切换到当前 `on` 的那一页时才建块取图（点击后 600ms / 1300ms、`hashchange`、`load` 各扫一次），不会一开页并发抓十几张。

顺带查出两个真 bug：

1. **`fetchSpotPhoto` 的内嵌分支不查别名**。它只认 `IMGS[name]` / `s:` / `n:`，而生成方把图存在 `IMGS['duke']` 这种短 key 上、靠 `V600_ALIAS` 映射。结果「独克宗古城」明明内嵌了 260KB 实拍图，函数却判定没图、转去联网（维基被墙）→ 12 秒后失败。已把别名匹配（精确 → 包含）加进函数内部，`.v46-rank`、日卡、详情页三处一起受益。
2. **一开页就并发抓十几张**。第一版扫描把 13 个详情页全部建块并发起请求，手机上等于一次开十几个联网任务。改成**只处理当前 `on` 的那一页**（点击后 600ms / 1300ms、`hashchange`、`load` 各扫一次）。

验收（无头 390×844，页面逐个点开）：路书 10 个详情页 `PHOTO 10/10`、模板 `v-spot-xuanwu` 有图、`#v-ocr` 未被误加、运行时错误 0。

## 4.15 v1.4：Day 标签对比度 + 景点页「返回 / 关闭」按真实来路

**用户给的三张截图 + 录屏**：① 深色模式下行程页「Day 1」选中标签是浅底压白字，几乎看不见；「待出发」徽标也是浅底浅字。② 行程页点「📸 景点打卡指引」进详情后，「返回」落到美食、「关闭」回行程。③ 美食 →「景点打卡 · 热度榜」→ 机位详情 →「返回上一级」直接回美食（应回热度榜那一层），「关闭」回美食（这层本来对）。

两处都做成追加层 `v14-fix-js`（模板与路书同字节注入，不改原结构、不改单个行程链接）：

- **对比度**：对 `.ptab.on` 强制 `linear-gradient(135deg,#0f766e,#0b5f59)` 深青底 + 纯白字（连 `-webkit-text-fill-color` 一起写，压过原内联浅色 radial-gradient）；`.todaydot`（含 `.is-wait`）改奶黄底 `#ffe3ae` + 深棕字 `#553100`。点击后、切主题、每 1.5s 重刷，深浅两档同一套色。
- **来路栈**：`__navTo` 被 V4.3 / V4.5 / V4.7 / v46 层层包过，本层**最后再包一层**，在跳转前把当前 `section.view.on` 记进栈：进板块清栈并把该板块记为 `entry`；进详情页（`v-spot-*`）压栈。
- **返回条改挂**：老 `v564` 返回条把目标写死在属性里（`back` 用建条时的 `LAST`、`close` 固定 `v-itinerary`），而 `installBars()` 只在首次安装时写 HTML，属性里永远是旧值。本层把 `data-v564-go` 摘掉、改挂 `data-v14-go`，用 document 捕获阶段的处理器自己算：`关闭` → `entry`（进入的那块，如行程）；`返回` → 栈顶上一页。
- **热度榜弹层（v46）**：`open/back/closeAll` 全在闭包里、不记来路。本层在弹层开着时每 400ms 存一份标题 + 内容快照（`ovSnap`）；从弹层点进机位详情（2.5s 内）记 `ovBack=1`，此时按「返回」用快照把热度榜原样放回来（不跳板块），按「关闭」仍回 `entry`（美食）。

验收（无头 Edge --headless=new，390×844@2x，`tpl_test.html` 副本）：
- 深/浅两档选中标签：`backgroundImage = linear-gradient(135deg, rgb(15,118,110), rgb(11,95,89))`、`color = rgb(255,255,255)`；`.todaydot` `bg rgb(255,227,174)` / `fg rgb(85,49,0)`。截图 `v14_dark.png` / `v14_light.png` 肉眼可读。
- 行程 → 景点详情：返回条已挂 `data-v14-go=1`、`data-v564-go` 为 `null`；点「返回」落 `v-itinerary`，点「关闭」落 `v-itinerary`，运行时错误 0。
- **诚实边界**：本机这份路书样本里 `#v-food` 没有「景点打卡 · 热度榜」入口（弹层由 v46 运行时构建、对外不暴露 `open()`），所以「从热度榜弹层点进机位详情」这一段只能用合成弹层验证「快照能回填」，未能端到端点通；真机上需再复看一次。快照回填不改弹层内部栈，v46 自己的 `back()` 语义保持不变。

## 4.16 v1.5：景点图统一走「自动识景 + 八平台搜图」

**用户要求**：景点指引的图要和行程顶部一样——自动识别景点，然后去小红书、高德、美团、携程、飞猪、百度、维基、360 搜图。

落地：

- `scripts/fetch_spot_photos.py` 原图源 4 个（360 / Bing / 百度 / 维基）扩到 6 个直连源：新增 **搜狗图片**（`pic.sogou.com/napi/pc/searchList`，国内直连）与 **百度百科词条主图**（`baike.baidu.com/api/openapi/BaikeLemmaCardApi`，词条主图命中率高于图库）。
- `--platforms` 默认改成 8 家：`xiaohongshu.com, amap.com, meituan.com, ctrip.com, fliggy.com, baidu.com, zh.wikipedia.org, so.com`，并接受中文别名（小红书 / 高德 / 美团 / 携程 / 飞猪 / 百度 / 维基 / 360）。每家都会追加一条 `景点名 site:<domain>` 的检索词，走直连图源把该平台已收录的实拍图捞回来——这些平台自身的图片接口要登录态或私有 key，脚本不硬碰鉴权。
- 标题闸门（标题必须含检索词）、尺寸闸门（短边 ≥640、长宽比 ≤2.4）、压图参数（长边 ≤1100、q68、非渐进）保持不变；一个源失败自动换下一个，不会出现「维基一超时就整页没图」。
- **三处共用同一套图**写死进 SKILL：行程顶部日卡、热度榜 `.v46-rank` 缩略图、机位详情页头图（`v13-spotdetail-js`）都走 `V543_IMGS` + `V600_ALIAS`，同景点同图。

验收（本机实测 2026-11）：`--spots` 单条「松赞林寺」跑完 8 家站内检索，360 命中 1100×716 / 175KB，写出 `photos.json` 1/1；`--help` 的 `--platforms` 默认值已含 8 家。

**诚实边界**：小红书 / 高德 / 美团 / 携程 / 飞猪没有免鉴权图片检索接口，脚本只能用 `site:` 检索拿搜索引擎已收录的图；若某景点在这些平台上只有带水印/登录墙的图，仍会落到「暂无实拍图」，此时按 SKILL 的兜底用 Agent 的 `image_search` 挑图并给 `"file"` 本地路径。

## 4.17 v1.6：Day tab 按实际天数生成 + 缺板块不跳首页

**用户反馈**：让 Workbody 做 7 天路书，顶部只有 4 个 Day 按钮，剩下 3 天全堆在页面下面；点「景点打卡」直接跳回首页。

两个都是模板/生成契约问题，不是单个行程的内容问题：

- **天数写死**：模板 `v-itinerary` 里 `for(d=0;d<4;d++)defs.push(...)`，`THEME` 也只有 4 条。第 5 天以后的 `.daycard` 从没被 `buildTabs` 收进 `defs`，所以没有 tab、也不会被 `show()` 隐藏，全堆在下面；`Day 1–4` 标题同样写死。
  改为 `iv.querySelectorAll('.daycard')` 取实际张数→生成 N 个 tab；`themeOf(i)` 对超出预置主题的天给「第 N 天」兜底；标题自动 `Day 1–N`；`全部` 文案写「全部 N 天」。
  另外追加 `v15-anyday-js`：对已经生成好的老页面，若 `#dayTabs` 的日 tab 数少于 `.daycard` 张数，就整组重建（含「全部」），点击切 `display`/`body[data-day]`/`dayBanner`，不依赖原闭包。
- **点打卡回首页**：Dock 的 `data-nav="v-spots"` 指向的板块被生成方整块删掉时，`__navTo` 找不到目标就回落首页。`v15-anyday-js` 在 `__navTo` 最外层加了守护：目标板块不存在时原地弹一条提示并中止跳转，不再默默回首页。同时 `scripts/check_demo_leftovers.py` 新增**结构闸门**：`v-home/v-prep/v-itinerary/v-spots/v-food/v-budget` 缺一个、或 Dock 指向不存在的板块，直接判失败（退出码 1），把问题拦在交稿前。

验收（无头 390×844，本机路书 8 天版）：
- `.daycard` 8 张 → `#dayTabs` 9 个（Day 1–8 + 全部），标题 `🗺 行程路线图 · Day 1–8`；
- 点 Day 7：`body[data-day]=7`、可见日卡 1 张、选中态落在 Day 7；
- `__navTo('v-not-exist')`：板块不变，弹「入口指向的板块不存在」，不再回首页；
- 模板 43 脚本 / 路书 44 脚本 `node --check` 全过，路书结构闸门通过（模板本身是示例内容，按设计仍会报残留）。

## 4.17 v1.6：Day tab 按实际天数生成 + 缺板块不跳首页

**用户反馈**：让 Workbody 做 7 天路书，顶部只有 4 个 Day 按钮，剩下 3 天全堆在页面下面；点「景点打卡」直接跳回首页。

两个都是模板/生成契约问题，不是单个行程的内容问题：

- **天数写死**：模板 `v-itinerary` 里 `for(d=0;d<4;d++)defs.push(...)`，`THEME` 也只有 4 条。第 5 天以后的 `.daycard` 从没被 `buildTabs` 收进 `defs`，所以没有 tab、也不会被 `show()` 隐藏，全堆在下面；`Day 1–4` 标题同样写死。
  改为 `iv.querySelectorAll('.daycard')` 取实际张数→生成 N 个 tab；`themeOf(i)` 对超出预置主题的天给「第 N 天」兜底；标题自动 `Day 1–N`；`全部` 文案写「全部 N 天」。
  另外追加 `v15-anyday-js`：对已经生成好的老页面，若 `#dayTabs` 的日 tab 数少于 `.daycard` 张数，就整组重建（含「全部」），点击切 `display`/`body[data-day]`/`dayBanner`，不依赖原闭包。
- **点打卡回首页**：Dock 的 `data-nav="v-spots"` 指向的板块被生成方整块删掉时，`__navTo` 找不到目标就回落首页。`v15-anyday-js` 在 `__navTo` 最外层加了守护：目标板块不存在时原地弹一条提示并中止跳转，不再默默回首页。同时 `scripts/check_demo_leftovers.py` 新增**结构闸门**：`v-home/v-prep/v-itinerary/v-spots/v-food/v-budget` 缺一个、或 Dock 指向不存在的板块，直接判失败（退出码 1），把问题拦在交稿前。

验收（无头 390×844，本机路书 8 天版）：
- `.daycard` 8 张 → `#dayTabs` 9 个（Day 1–8 + 全部），标题 `🗺 行程路线图 · Day 1–8`；
- 点 Day 7：`body[data-day]=7`、可见日卡 1 张、选中态落在 Day 7；
- `__navTo('v-not-exist')`：板块不变，弹「入口指向的板块不存在」，不再回首页；
- 模板 43 脚本 / 路书 44 脚本 `node --check` 全过，路书结构闸门通过（模板本身是示例内容，按设计仍会报残留）。

## 4.18 v1.7：天数变量化 + 红线（禁止删改框架）

**用户口径**：别写死 7 天 8 天，用户玩几天就几天，天数是变量不是死量；并在 skill 里加红线，要求所有大模型严格执行，禁止删改。

落地：

- SKILL.md 顶部（「核心原则」之前）新增 **红线（Red Line）** 四条：① 天数只按 `.daycard` 张数生成，禁止 `for(d=0;d<4)`、`Day 1–4`、「四天全部显示」这类固定天数；② 板块 id（`v-home/v-prep/v-itinerary/v-spots/v-food/v-budget` 及各 `v-spot-*`）与既有功能（Dock、返回/关闭、滚动记忆、自定义背景、实拍图、票据、记账、二维码）只能换内容，禁止删除/改名/关闭；③ 任何入口的落点必须真实存在；④ 交稿前必须跑自检脚本且退出码 0。
- `check_demo_leftovers.py` 的结构闸门新增三项硬检：`.daycard` 张数为 0、命中 `for(d=0;d<4)`、命中「四天全部显示」——任一命中直接判失败。
- 模板本身已无固定天数：`buildTabs` 的 defs 由 `.daycard` 数量生成；`THEME` 仅作前 4 天的配色预置，超出部分 `themeOf()` 回退「第 N 天」，不构成天数限制。

验收：本机 8 天路书 `.daycard` 8 → tab 9（Day 1–8 + 全部）；`check_demo_leftovers.py` 对该路书退出码 0；模板自身是示例内容，按设计仍会报残留，但结构闸门通过。

## 4.19 v1.8：兼容性加固（让「不太会写码」的模型也能跑对）

**用户要求**：提高代码兼容性，让一些蠢模型也能顺利执行。

做法不是写更多解释，而是**把判断变成脚本、把容错做进模板**：

- 新增 `scripts/verify_roadbook.py`：一条命令做六件事——文件体积、必需板块、Dock 落点、`.daycard` 与写死天数、模板示例残留（转调 `check_demo_leftovers.py`）、内联 JS 语法（有 node 才跑，没有明确 SKIP）。任何一项 FAIL 都打印「怎么修」的 4 条固定指引，并返回退出码 1。
- SKILL 顶部新增「傻瓜执行清单」5 步：复制框架 → 一天一张 `.daycard`（不碰 `#dayTabs`）→ 抓图/嵌图命令 → `verify_roadbook.py` 必须 PASS → 交付链接 + 二维码 + zip。
- 模板容错：日卡选择器从 `.daycard` 放宽到 `.daycard, [data-day]`；`#dayTabs` 容器被删掉时，`v15-anyday-js` 会在第一张日卡前自建一个，再按张数生成 tab。这样即使模型把 tab 容器写丢、或日卡忘了写 class 只写了 `data-day`，也仍能出正确的 Day 导航。

验收：本机 8 天路书 `verify_roadbook.py` 退出码 0（8 张日卡、9 个 tab、44 个脚本语法全过）；模板自身因是示例内容，`check_demo_leftovers` 仍报残留（设计如此），但结构与天数闸门通过。

## 4.20 v1.9：红线加「功能全量执行」+ 机器硬检

**用户要求**：再加一条红线——所有大模型必须严格、完全执行 skill 里的所有功能。

- SKILL「红线」新增第 4 条：**功能必须全量实现，一条都不许少**。逐条点名：Day tab、实拍图（`V543_IMGS`/`V600_ALIAS`）、机位详情、景点打卡热度榜、美食三 tab、返回/关闭条、Dock、滚动位置记忆、自定义背景、票据识别、多人记账与预算、景区导览图、二维码。明确禁止以「内容不一样 / 简化 / 用不到 / 示例是别人的」为由删除、关闭、注释、空壳化；用户没明确说不要，就必须留。
- `scripts/verify_roadbook.py` 新增 9 项功能标记硬检：`V543_IMGS`、`V600_ALIAS`、`v46-ov`、`v564-back`、`__navTo`、`id="v-ocr"`、`id="v-budget"`、`id="v-spots"`、`id="v-itinerary"`。缺任何一项直接 FAIL，并在输出里写明缺的是哪项功能。

验收：本机 8 天路书 `verify_roadbook.py` 输出 `PASS 可以交付`（板块、Dock、8 张日卡、9 项功能标记、44 个脚本语法、示例残留全部通过）。

## 4.21 v2.0：模板去示例化（只留框架）

**用户要求**：skill 里不能保留南京那个行程的详细内容，删掉详细内容、保留框架。

做法：

- 清空四个数据源：`var S=[]; var F=[]; var SPOTS=[]; var MEALS=[];`（原来内嵌的杭州/南京景点、餐厅、机位、餐次全删）。
- 清空 `window.V543_IMGS={}` 与 `window.V600_ALIAS={}`（原来 2.8MB 的示例实拍 base64 全部移除）。
- `#v-itinerary` 的 4 张真实日卡（每张上百 KB）换成 4 张占位卡：只有 `.dayhero` + `Day N` + `.daybody` 里的「第 N 天 · 目的地 / 在这里写当天行程」。
- 可见文案里的示例地名、日期、价格统一换通用词（示例城市 / 示例景点 / 日期 / N 人 / ¥—）；`<script>`、`<style>` 内的类名与逻辑不动。
- 结果：模板 3,846,969B → 1,973,682B，`section.view` 仍 38 个，43 个脚本 `node --check` 全过，无头加载 `Runtime.exceptionThrown` = 0。

验收（无头 390×844）：`sections 38 / daycards 4 / tabs 5 / 切 v-itinerary、v-spots 正常 / 错误 0`。

**注意**：模板现在是空白框架，生成时必须自己填 `S/F/SPOTS/MEALS` 与日卡内容；`verify_roadbook.py` 会检查 `V543_IMGS`/`V600_ALIAS` 等标记是否存在（空对象也算存在），但不会替你写行程。

## 4.22 v2.1：连注释里的示例地名一起清掉

**用户要求**：注释也要删；并追问「删完后没有动其他东西吧」。

做法与边界：

- 删掉 4 处含示例地名的注释（CSS 的「夫子庙子页」「西湖官方导览图」两段说明等）。
- 脚本里**会真的渲染出来**的残留地名也一并换掉：浏览器标题兜底 `杭州南京赏秋路书` → `旅行路书`；两条抢票提醒（灵隐飞来峰 / 中山陵）→ 通用「行前预约提醒（示例）」；热度榜分组标题与来源文案、`THEME` 主题名、官方导览图标签 → 示例城市 / 示例景点 / 示例导览图。
- **不动**任何函数、选择器、section id、DOM 结构、交互逻辑；只改注释与字符串字面量。43 个脚本 `node --check` 全过。
- `check_demo_leftovers.py --strict-code` 现在 **0 残留**（48 个示例词全站零命中）。

验收：无头 390×844 → `sections 38 / daycards 4 / tabs 5 / Runtime.exceptionThrown 0`；`verify_roadbook.py` 对本机路书仍 PASS。

## 4.24 v2.3：切板块回来不许弹到底部/中部（滚动记忆修正）

**用户反馈**：板块初始在顶部，切另一个板块再切回来变成底部；有的页面回来是中部。

**根因（无头复现）**：滚动记忆只为 `y>0` 写值，`0` 被当成「没记忆」。于是「滚到 900 → 手动回到顶部 0」时，`v-itinerary` 的记忆仍停在 900；再切走切回，`go()` 取 `scrollMemo[tid]=900`，直接弹回 900（或目标页更矮时被 `scrollTo` 钳到底部）。另外 Dock 的 `pointerdown` 可能在 `click` 前就切换页面，晚一步保存会把新页的过渡位置写进旧页。

**修法**：追加 `v23-scrollfix-js`（纯追加层，不动原逻辑）：

- `pointerdown` / `touchstart` / `click`（capture）先 `save()` 当前板块的 `pageYOffset`，**包括 0**，再启动目标板块的落地校正；
- `__navTo` 最外层再包一次，函数式导航也先存位置；
- 落地后 0/300/800/1300/1800/2300ms 六次 `scrollTo` 到记忆位；目标页 `maxScroll < 记忆位` 时按 `0`（顶部）处理，不钳到底部；
- 触摸 / 滚轮 / pointerdown 立即 `userStop=true`，用户一动手就不再用程序位置抢；
- 过渡期间（2.4s）滚动监听不写记忆，落地后再存一次。

**实测（无头 390×844，真实 pointerdown + click）**：

- 行程滚到 900 → 点 Dock 美食 → 再点行程：回到 **900**；
- 行程滚回顶部 0 → 美食 → 返回：仍是 **0**（修复前是 900）；
- 准备 / 记账 / 打卡 各自顶部往返：全部 **0**；`Runtime.exceptionThrown=0`。

## 4.25 v2.4：顺路 / 不顺路美食必须有真区别

**用户反馈**：「顺路的美食和不顺路的美食一点区别都没有，你到底有没有写寻找代码？」

**根因**：旧版只有手写的 `route:1/0` 标记，没有按本次行程算；更糟的是「本地美食」页把 `on`（顺路）又渲染了一遍，13 道里只多 3 道绕路款，看起来两页一样。

**修法**：

- 新增 `__v24Route(f)`：先看 `g` 是否含「本次未安排 / 需绕路 / 不经过」→ 绕路；否则按 `g` 的 `Day X–Y` 去比对 `#v-itinerary .daycard` 的正文，命中 `f.c`（城市/地区）才算顺路，不再只信手写 `route`。
- 默认页只渲染顺路款，按城市分组并显示「✓ 顺路 N 道 / ↗ 需绕路 M 道」；「本地美食 · 需绕路」页**只渲染 `route:0`**，不再复制顺路款，两页 0 重复。
- 新增 `#v46-near`「🔎 附近美食」：手机允许定位时直接开高德 `center=经度,纬度&radius=3000`，拒绝定位则开高德美食搜索。
- `verify_roadbook.py` 增 `check_food()`：`F` ≥4 条且 `route:0` 为 0、缺 `v24-foodroute`、缺 `v46-near`、本地页仍 `groupHTML(on,…)`，任一命中即 FAIL。

**实测（无头 390×844，样本路书）**：默认页 `v46-food` 10 道；点「本地美食」页 3 道（丽江腊排骨 / 泸沽湖猪膘肉 / 梅里酥油煎奶渣）；两页无重复；`Runtime.exceptionThrown=0`。

## 4.26 v2.5：把红线变成可执行的多层硬闸门

**背景**：前几版红线写了「不许删功能 / 每个景点要有详情页」，但 `verify_roadbook.py` 只查 Dock 和必需板块，WorkBuddy 省掉 10 个 `v-spot-*` 仍能 PASS。用户要求「写严格一点，不要让其他模型偷工减料」。

**本次把 `verify_roadbook.py` 重写为硬闸门**：

1. 结构：板块 ≥30（模板基线 38）、Dock ≥5 项、必须有 `#dayTabs`；日卡 `data-day` 必须 1..N 连续。
2. 导航：`data-nav / data-v46-go / data-v15-go / data-v564-go / data-dock` 目标必须存在。
3. 详情：`S` 数组 `d:'v-spot-*'` 目标必须存在；`v-spot-*` ≥3；每个详情页正文 ≥80 字、有 `.hero`、有 `data-img`/`v600-detail-photo`。
4. 图片：`V543_IMGS` 至少一张内嵌 `data:image/`。
5. 版本：首页 `#rbVer` + `#wechatTip` 同号，格式 `vX.Y`。
6. 美食：`F` 每条必须有 `c/g/rests`；≥4 条时不许全 `route:1` 或全 `route:0`；必须有 `v24-foodroute`、`#v46-near`，本地页不许 `groupHTML(on,…)`。
7. 占位：非空白模板正文不许出现 `TODO/待补/待填/暂无内容/占位/示例城市/共 0 个点位`。
8. 脚本：逐段 `node --check`；`check_demo_leftovers.py` 退出码 0。

**结果**：模板 PASS（38 板块/4 日卡）；样本 PASS（34 板块/8 日卡）；WorkBuddy 那份从「3 项 FAIL」变成 **14 项 FAIL**，含「板块只有 25 个」「S 详情页目标缺 13 个」「详情页 0 个」「没有滚动修复层/顺路判定层/附近美食/版本徽标」「正文还有示例城市」。

## 4.27 v2.6：Day 1–16 / 双数空白 + 首页左缘尖箭头

**用户反馈（WorkBuddy 2026-11-16-20-56-25 那份）**：① 首页左侧多出一个尖尖的箭头状物体；② 要 7 天，行程页却是 Day 1–16 十六个 tab，逢双数的日期全空白。

**根因 1（skill bug，不是 WorkBuddy 独有）**：模板的初版 `buildTabs` 与追加层 `v15-anyday-js` 都用了并集选择器 `querySelectorAll('.daycard, [data-day]')`。页面里 `data-day` 不只日卡有——`body[data-day]`（当前天状态）和 8 个 `.v514-art[data-day]`（日卡底部装饰主题图）也带。于是 8 张真日卡被算成 16 张，生成 Day 1–16；双数 tab 对应装饰层，`show()` 把真日卡全隐藏后自然空白。第二处误判是 `if(n>=cards.length)`：旧 tab 数只要不少于（或等于）错误 card 数就提前 return，不再纠正。

**修法**：`buildTabs` 与 `v15-anyday-js` 的日卡统计一律只用 `.daycard`；老页面兜底改为 `.card[data-day]`（不再 `getElementsByClassName('card')` 把非日卡也算进来）；建 tab 插入点也只用 `.daycard`；tab 数量判定改成 `n===cards.length`，不相等就重建。

**根因 2（WorkBuddy 生成时的游离字符，skill 闸门漏检）**：文件 offset 约 4,941,212 处，V5.68-78 追加层 `</script>` 后有一个裸 `>` 文本节点（`</script>\n>\n\n<!-- V5.68-78 END -->`）。浏览器把它当正文渲染到屏幕左缘，就是红圈里的「尖尖箭头」；它不是图标、不是 `#goTop`（`#goTop` 在右侧、默认 `opacity:0`、`pointer-events:none`）。

**验证（无头 Edge 390×844@2x，真实点击）**：

| 版本 | 日卡 | `[data-day]` 总数 | 数字 tab | 标题 | Day 2 点开 |
|---|---|---|---|---|---|
| 原 WorkBuddy | 8 | 17（8 卡 + body + 8 装饰） | 16 | Day 1–16 | 可见日卡 0、正文 0 字（空白） |
| 只改选择器+删裸 `>` | 8 | 17 | 8 | Day 1–8 | 可见日卡 1、正文 975 字 |

原文件 `body` 直接子级裸 `>` 文本节点 = 1；修后 = 0，首页截图左缘不再有箭头。

**诚实边界**：这份 WorkBuddy 内容本身是 8 天 7 晚（11/23–11/30），用户口头要 7 天；skill 无法从 HTML 反推用户原始要求，只能保证「页面写几天就几个 tab、标题与日卡数一致」。生成方必须按用户说的天数写 N 张日卡；verify 会拦「标题 N 与日卡数不一致」，但不会替生成方删掉多出来的一天。新增 `--expect-days N` 参数：生成方把用户明确说的天数传进去，日卡数不是 N 就直接 FAIL（本份 8 天版传 `--expect-days 7` 会明确报「用户要 7 天，页面却有 8 张」）。

## 5. 已知边界（诚实记录）

- 静态 HTML 无后端：真·AI「识图/重绘」无法在运行时调用大模型。**V6.00 起景点图只允许实拍**：构建期由生成方用 `image_search` 抓图 → 压 JPEG（长边 ≤1100、q68、非渐进）→ base64 写入 `V543_IMGS`，再用 `V600_ALIAS` 把热度榜行名映射到 key。运行时联网（维基 REST/搜索）只是兜底，抓不到就显「暂无实拍图」，**不许用程序化 SVG 冒充**。美食配图仍是程序化 SVG（`v564` 层），两者互不替代。
- 景点识别是字符串匹配：卡片里必须出现景点名（或同组 h3 里有地区名）才能命中；只写「古城」这种两字简称会退到地区级配色（不影响可用，只是景别粗一点）。
- 联网抓图在国内基本不可用：实测本机访问 `zh.wikipedia.org` 20s 超时；百度图片 `acjson` 虽可达，但 `Access-Control-Allow-Origin` 只回 `https://image.baidu.com`、且 `callback` 参数已失效（返回纯 JSON），静态页既 fetch 不了也 JSONP 不了。**结论：运行时抓图只能当兜底，主路径必须是构建期内嵌。**
- 热度榜缩略图依赖 `V600_ALIAS`：新景点只写名字不补别名，就会显示「无图」——这是有意的显性失败，方便验收时一眼看出来。
- OCR.space 为第三方免费接口，超限或被拦截时给出「改用微信提取文字粘贴」的兜底路径。
- 动画类 bug（Dock 下沉、转场渐变）在无头 `--virtual-time-budget` 下**不会真正播放**：`getComputedStyle` 读到的是冻结值，只能用「style 属性 / className / transition 声明」这类状态证据验收，不能靠截图里的中间帧。

## 4.27 v2.7：删掉行程正文的隐约底纹 + 补两天景点图 + Day 选中不再变深色

**用户反馈**：图1 红框（Day1 06:50/07:49 时间线）下有一张隐约图片；最新 7 天版有两天景点图找不到；Day 日期按钮和「待出发/今天」点一下变深色，选中/未选中区分不了。

**根因与修法**：

- **红框下的“图片”不是 `<img>`，也不是 `.dayhero` 空图位**：运行时逐个数到 `#v-itinerary .v50-wash` 共 7 个、`opacity:.06`、背景是 `data:image/svg+xml;base64,...` 装饰底纹；`.v50-mid` 同为 SVG（`.10`）；`.v514-art` 已由旧层 `display:none` 且实际 DOM 为 0。新增 `v27-fix-css` 对 `#v-itinerary .card.daycard .v50-wash/.v50-mid/.v50-dayart` 统一 `display:none!important`，深/浅两档同一条规则，不依赖主题颜色，避免“改完深色浅色又看不清”。
- **两天没图精确是 Day1 广州、Day3 稻城**（不是 Day7）：Day2/4/5/6/7 的 `.dimg` 已有背景；Day1/3 的 `SPOTS` 精确别名只有「广州南站 / 稻城白塔」，Day 标题只写「广州 / 稻城」，`findSpot` 落入 `g_广州 / g_稻城` 泛化 key，`V543_IMGS` 里虽有 `gz/daocheng` 却取不到。修法两层：① 模板 `findSpot` 增加 2–4 字 `SPOTS[i].name` 前缀反查，且只在 `IMGS[key]||ORIG[key]` 有图时采用；② 新增 `v27-fix-js`，从页面自身 `<script>` 的 `var SPOTS=[...]` 解析（WorkBuddy 把 SPOTS 放在闭包里、没挂 `window`），自动把全名/原别名/2–4 字前缀写进 `V600_ALIAS`，并直接对 `.daycard .dimg` 兜底补图、移除 `v600-noph` 与 `.v543-auto` 角标；每 1.5s 重跑一次，防止旧 `paintHero` 异步回落。**不写死城市、不写死天数。**
- **Day 标签/提醒不再点一下变深色**：用户明确拒绝「选中深青底白字」。`v27-fix-css`/`v27-fix-js` 把选中态改白底深字（`#0b4b46`）+ 1px `#0f766e` 描边 + 3px 外环 + 底部 3px 色条 + 800 字重；未选中为 `rgba(255,255,255,.92)` 浅玻璃 + 细边框；`.todaydot` 保持奶黄底 `#ffe3ae` + 深棕字 `#553100`，不再整颗变深。边框宽度选中/未选中都是 1px，点按不产生宽度跳动。

**验收（无头 Edge 390×844，修复副本）**：

- 7/7 天 `.dimg bg=url("data:image/jpeg;base64,...")`、`class="dimg"`、无「找图中/暂无」角标；Day1 广州、Day3 稻城均补上实拍。
- 深/浅两档选中 Day1：`bg rgb(255,255,255)`、`color rgb(11,75,70)`、`border rgb(15,118,110)`、`box-shadow` 含外环/底条；未选中 `bg rgba(255,255,255,.92)`、同色深字、细边框。`.todaydot` 奶黄/深棕。
- `#v-itinerary .v50-wash` 7 个全部 `display:none`；`verify_roadbook.py` 对模板 PASS（38 板块/4 日卡），对修复版 PASS（41 板块/7 日卡）；行程→景点详情页「返回」「关闭」均实测回 `v-itinerary`。

**诚实边界**：本机无头下 `window.scrollTo` 被页面滚动层拦截（`scrollY=0`），底纹是靠 DOM/计算样式定位，不是靠滚动截图逐点确认；真机滚动时若仍有残留，需要再复看 `.v50-mid` 的实际 opacity。`SPOTS` 前缀在多城市同名景点上可能误配（当前按「最早位置 + 最长 token + 有图」排序），需用多城市样本回归。
